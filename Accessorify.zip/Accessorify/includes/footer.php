<footer>
    <div class="container">
        <div class="row pb-3 border-bottom-hr">
            <div class="col-lg-6 col-sm-12 mb-40">
                <div class="row">
                    <div class="col-lg-6 col-sm-12">
                        <h6 class="fw-300 fs-16 fc-secondary mb-15">ACHETER</h6>
                        <ul>
                            <li class="mb-2"><a href="index.php">ACCUEIL</a></li>
                            <li class="mb-2"><a href="catalogue.php">BOUTIQUE</a></li>
                            <li class="mb-2"><a href="about.php">À PROPOS DE NOUS</a></li>
                            <li class="mb-2"><a href="contact.php">CONTACTEZ-NOUS</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-6 col-sm-12">
                        <h6 class="fw-300 fs-16 fc-secondary mb-15">GESTION</h6>
                        <ul>
                            <li class="mb-2"><a href="customer-profile.php">MON COMPTE</a></li>
                            <li class="mb-2"><a href="index.php">POLITIQUE DE CONFIDENTIALITÉ </a></li>
                            <li class="mb-2"><a href="index.php">POLITIQUE EN MATIÈRE DE COOKIES</a></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-sm-12 mb-40">
                <div class="row">
                    <div class="col-lg-6 col-sm-12">
                        <h6 class="fw-300 fs-16 fc-secondary mb-15">BESOIN D'AIDE </h6>
                        <p class="fs-13 mb-15 fc-secondary-400" style="line-height: 1.4;">AVEZ-VOUS UNE QUESTION ? VOUS POURRIEZ TRIUVER UNE RÉPONSE DANS NOS FAQ. MAIS VOUS POUVEZ AUSSI NOUS CONTACTER: </p>
                        <ul>
                            <li class="mb-2"><a href="tel:<?php echo $site__phone; ?>">APPELEZ-NOUS :<?php echo $site__phone; ?></a></li>
                           
                            <li class="mb-2"><a href="mailto:<?php echo $site__email; ?>">ENVOYEZ-NOUS UN E-MAIL</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-6 col-sm-12">
                        <h6 class="fw-300 fs-16 fc-secondary mb-15">SUIVEZ-NOUS</h6>
                        <ul>
                            <li class="mb-2">
                                <span class="icon__wrap fc-secondary"><i class="ri-facebook-line"></i></span>
                                <a href="https://www.facebook.com" target="_blank">facebook</a>
                            </li>
                            <li class="mb-2">
                                <span class="icon__wrap fc-secondary"><i class="ri-instagram-line"></i></span>
                                <a href="https://www.instagram.com" target="_blank">Instagram</a>
                            </li>
                            <!-- <li class="mb-2">
                                <span class="icon__wrap fc-secondary"><i class="ri-twitter-line"></i></span>
                                <a href="https://x.com" target="_blank">X</a>
                            </li> -->
                            <li class="mb-2">
                                <span class="icon__wrap fc-secondary">
                                <img src="assets/images/images/x-logo-twitter-elon-musk.png" alt="X" style="width: 20px; height: 20px;"></span>
                                <a href="https://www.twitter.com" target="_blank">    X</a>
                            </li>


                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="row">
                    <div class="flex-1">
                        <div class="logo d-flex align-items-center gap-10">
                            <img src="assets/images/logos/logo-black.png" width="30px" alt="">
                            <p class="fs-14 fw-300 fc-secondary-400">Droits d'auteur © <?php echo date('Y') ?> - <?php echo $site__name; ?></p>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-12 col-sm-12">
                        <div class="d-flex gap-10">
                            <img src="assets/images/payments/icons.png" height="20" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>





<?php include('includes/footer-scripts.php') ?>