<!--==== LIBRARY FILES START =====-->
<script src="assets/js/libs.js"></script>
<!--==== LIBRARY FILES END =====-->

<!--==== FANCYBOX START =====-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<!--==== FANCYBOX END =====-->

<!--==== LOCAL FILES START =====-->
<script src="assets/js/script.js"></script>
<!--==== LOCAL FILES END =====-->