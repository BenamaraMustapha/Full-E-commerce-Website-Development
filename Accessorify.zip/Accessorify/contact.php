<?php include 'config.php'; ?>
<?php include 'functions.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- META TITLE AND DESCRIPTION -->
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!-- META TITLE AND DESCRIPTION -->


    <!--==== HEADER STYLES START ====-->
    <?php include('includes/header-styles.php') ?>
    <!--==== HEADER STYLES END ====-->
    <title>Contact | <?php echo $site__name; ?></title>
</head>

<body>

    <!--==== HEADER START ====-->
    <?php include('includes/header.php') ?>
    <!--==== HEADER END ====-->
    <main>
        <section class="contactSection py-5 my-5">
            <div class="container">
                <div class="row center">
                    <div class="col-md-5 col-12 map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29037.08412112858!2d5.3698!3d43.2965!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12c9c03e3b5d120f%3A0x2e72a3f06e4f5c0!2sMarseille%2C%20France!5e0!3m2!1sen!2s!4v1699813015816!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="col-md-7 col-12">
                        <div class="contactForm">
                            <h4 class="text-left fs-24 fw-300 ff-secondary mb-15">Laissez-nous un message
                            </h4>
                            <p class="fs-15 fc-secondary-400 fw-300 ff-secondary mb-15">Nous serons heureux de répondre à toutes vos questions ou de vous fournir une estimation. Il vous suffit de nous envoyer un message dans le formulaire ci-dessous avec toutes les questions que vous pourriez avoir.

                            </p>
                            <div class="form_wrap">
                                <form action="">
                                    <div class="row">
                                        <div class="col-12">
                                            <label for="" class="fs-14 fw-300 ff-secondary mb-1">Nom
                                            </label>
                                            <input data-validate-msg type="text" class="ct_name fs-14  border py-2 px-2 mb-2">
                                        </div>
                                        <div class="col-12">
                                            <label for="" class="fs-14 fw-300 ff-secondary mb-1">E-mail
                                            </label>
                                            <input data-validate-msg data-validate-msg-email type="email" class="ct_email fs-14  border py-2 px-2 mb-2">
                                        </div>
                                        <div class="col-12">
                                            <label for="" class="fs-14 fw-300 ff-secondary mb-1">Numéro de téléphine
                                            </label>
                                            <input data-telephone-msg-field data-validate-msg type="tel" class="ct_phone fs-14  border py-2 px-2 mb-2">
                                        </div>
                                        <div class="col-12">
                                            <label for="" class="fs-14 fw-300 ff-secondary mb-1">Message
                                            </label>
                                            <textarea data-validate-msg class="cta_message fs-14 w-100 d-block mb-2 border py-2 px-2 outline-none" name="" id="" cols="30" rows="10" placeholder="Saisir votre message" style="outline: none !important;"></textarea>
                                        </div>
                                    </div>
                                    <button data-msg class=" btn btn-secondary d-block mt-3 w-100 mw-100">SOUMETTRE</button>
                                    <p id="formSubmit" class="py-4" style="display: none;"></p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </section>
    </main>
    <!--==== FOOTER START ====-->
    <?php include('includes/footer.php') ?>
    <!--==== FOOTER END ====-->
</body>

</html>