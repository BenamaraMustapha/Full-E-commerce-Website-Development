-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 25 mai 2024 à 22:24
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `pr`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `Admin Id` int(11) NOT NULL,
  `Admin Name` varchar(255) NOT NULL,
  `Admin Email` varchar(255) NOT NULL,
  `Admin Password` varchar(255) NOT NULL,
  `Admin Phone` varchar(255) NOT NULL,
  `Rights` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`Admin Id`, `Admin Name`, `Admin Email`, `Admin Password`, `Admin Phone`, `Rights`) VALUES
(1, 'Admin', 'admin@gmail.com', '123', '1234567890', '1'),
(9, 'Sub-admin', 'subadmin@gmail.com', '1234', '1234567812', '2');

-- --------------------------------------------------------

--
-- Structure de la table `cart`
--

CREATE TABLE `cart` (
  `Cart Id` int(11) NOT NULL,
  `Customer Id` int(11) NOT NULL,
  `Products` longtext NOT NULL,
  `Product Quantity` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `cart`
--

INSERT INTO `cart` (`Cart Id`, `Customer Id`, `Products`, `Product Quantity`) VALUES
(12, 24, '', ''),
(13, 25, ' G-805307', '1'),
(14, 26, 'BA-246336', '1'),
(15, 27, '', ''),
(16, 28, '', ''),
(17, 29, '', ''),
(18, 30, '', ''),
(19, 31, 'GR-773455', '1');

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE `category` (
  `Category Id` int(255) NOT NULL,
  `Category Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `category`
--

INSERT INTO `category` (`Category Id`, `Category Name`) VALUES
(4, 'Chapeaux'),
(5, 'Sacs à main'),
(11, 'Produits de beauté'),
(12, 'Accessoires Cadeaux'),
(13, 'Arts'),
(14, 'Portefeuilles'),
(17, 'Bracelets'),
(18, 'Carte de Vœux');

-- --------------------------------------------------------

--
-- Structure de la table `customer`
--

CREATE TABLE `customer` (
  `Customer Id` int(11) NOT NULL,
  `Customer Name` varchar(255) NOT NULL,
  `Customer Email` varchar(255) NOT NULL,
  `Customer Password` varchar(255) NOT NULL,
  `Customer Phone` int(255) NOT NULL,
  `Customer Address` varchar(255) NOT NULL,
  `Customer City` varchar(255) NOT NULL,
  `Customer Zipcode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `customer`
--

INSERT INTO `customer` (`Customer Id`, `Customer Name`, `Customer Email`, `Customer Password`, `Customer Phone`, `Customer Address`, `Customer City`, `Customer Zipcode`) VALUES
(24, '123', '1234@gmail.com', '123', 120371023, 'this is my address', 'Marseille', '13002'),
(25, 'test', 'test@gmail.com', '123', 1234567890, 'test address', 'Paris', '75001'),
(26, 'Mustapha', 'mustapha@gmail.com', 'must123', 2147483647, '', '', ''),
(27, 'Anis', 'anis@gmail.com', '123', 2147483647, '', '', ''),
(28, 'celine', 'celine@gmail.com', '123', 123, '', '', ''),
(29, 'new', 'new@gmail.com', '123', 2147483647, '', '', ''),
(30, 'treize', 'treize@mailinator.com', 'Oyzyo', 3122, '', '', ''),
(31, 'OK', 'ok@gmail.com', '123', 1234, '', '', '');

-- --------------------------------------------------------

--
-- Structure de la table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `feedback_message` text NOT NULL,
  `product_id` varchar(255) NOT NULL,
  `feedback_date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `feedback`
--

INSERT INTO `feedback` (`id`, `customer_name`, `feedback_message`, `product_id`, `feedback_date_time`) VALUES
(6, '123', 'J\'ai acheté ce produit il y a quelques jours et j\'en suis vraiment ravi. La qualité est excellente et il correspond parfaitement à mes attentes. Je le recommande vivement à tous ceux qui cherchent un accessoire fiable et durable.', 'IS-511272', '2023-11-12 19:44:24'),
(7, '123', 'Malheureusement, je suis un peu déçu par ce produit 😣😣😔. Bien que l\'aspect soit agréable, les fonctionnalités sont limitées et la durabilité semble moyenne. Je ne suis pas sûr de le recommander à mes amis.', 'IS-511272', '2023-11-12 19:52:58'),
(8, '123', 'Je recommande fortement ce produit, Merci Accessorify.', 'BA-308884', '2023-11-12 19:55:23'),
(9, '123', 'Impeccable 😁', 'BA-308884', '2023-11-12 20:01:37');

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `message` text NOT NULL,
  `message_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `phone_number`, `message`, `message_time`) VALUES
(1, 'Anis', 'anis@gmail.com', '03201291613', 'Bonjour ! Je voudrais connaitre les délais de livraison svp.', '2024-05-12 17:40:04'),
(2, 'Treize', 'treize@mailinator.com', '3105552766', 'Message test , merci !', '2024-05-12 17:44:01'),
(3, 'Mustapha', 'mustapha@gmail.com', '03201291613', '123', '2024-05-15 19:08:55');

-- --------------------------------------------------------

--
-- Structure de la table `order`
--

CREATE TABLE `order` (
  `Order Id` int(255) NOT NULL,
  `Order Number` varchar(255) NOT NULL,
  `Customer Id` varchar(255) NOT NULL,
  `Order Type` varchar(255) NOT NULL,
  `Order Amount` varchar(255) NOT NULL,
  `Order Date` varchar(255) NOT NULL DEFAULT current_timestamp(),
  `Order Items` longtext NOT NULL,
  `Order Items Quantity` longtext NOT NULL,
  `Order Status` varchar(255) NOT NULL,
  `Order Address` varchar(255) NOT NULL,
  `Order City` varchar(255) NOT NULL,
  `Order Phone` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `est_delivery_date` varchar(255) NOT NULL,
  `delivery_date` varchar(255) NOT NULL,
  `cancel_by` varchar(255) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `order`
--

INSERT INTO `order` (`Order Id`, `Order Number`, `Customer Id`, `Order Type`, `Order Amount`, `Order Date`, `Order Items`, `Order Items Quantity`, `Order Status`, `Order Address`, `Order City`, `Order Phone`, `reason`, `est_delivery_date`, `delivery_date`, `cancel_by`, `order_date`) VALUES
(39, '971952403776', '24', 'Cash on Delivery', '63.5', '11-11-23', 'BA-308884, G-805307,IS-511272', '1, 1, 1', 'delivered', 'this is my address', 'Bordeaux', '120371023', '', '2024-05-16', '2024-05-12', '', '2024-05-11 20:27:36'),
(46, 'C_03272046901910', '24', 'Cash on Delivery', '19.5', '12-11-23', 'BA-308884', '1', 'cancelled', 'this is my address', 'Paris', '120371023', '', '', '', 'admin', '2024-05-15 08:57:56'),
(47, 'E_25227223278559', '24', 'Ejuhp', '22', '12-11-23', ' G-805307', '1', 'delivered', '4413 Beverly Dr', 'Nice', '4413123123123', '', '2024-05-16', '2024-05-12', '', '2023-11-12 12:19:32'),
(48, 'C_15012880437151', '24', 'Card Payment', '19.5', '12-11-23', 'BA-308884', '1', 'delivered', 'this is my address', 'Marseille', '120371023', '', '2024-05-16', '2024-05-12', '', '2024-05-12 19:03:06');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `Product Id` int(11) NOT NULL,
  `Product Name` varchar(255) NOT NULL,
  `Product Stock` int(11) NOT NULL,
  `Product Category` varchar(255) NOT NULL,
  `Product SKU` varchar(255) NOT NULL,
  `Images` text NOT NULL,
  `Keywords` varchar(255) NOT NULL,
  `Warranty` varchar(50) NOT NULL,
  `Product Price` varchar(255) NOT NULL,
  `Product Description` varchar(255) NOT NULL,
  `Product Brand` varchar(255) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`Product Id`, `Product Name`, `Product Stock`, `Product Category`, `Product SKU`, `Images`, `Keywords`, `Warranty`, `Product Price`, `Product Description`, `Product Brand`, `upload_date`) VALUES
(47, 'Istanbul Portefeuille', 21, 'Portefeuilles', 'IS-511272', 'IMG-654be451cca2b3.89862110.jpg', 'portefeuille, ballet, fashionista, accessoire, style, tendance, élégant, chic, vintage, moderne, luxe, premium, designer, cuir, cuir véritable, synthétique, porte-cartes, porte-monnaie, porte-billets, fermeture éclair, bouton-pression, rabat, pochette', 'W-392480', '99.99', 'Portefeuille de qualité en cuir, fabriqué à Istanbul. Design épuré et compartiments pratiques. Un accessoire mode alliant fonctionnalité et élégance.', 'jafferees', '2024-04-09 17:12:35'),
(48, ' Carte De Vœux Avec Mini Envelope', 22, 'Cartes de vœux', ' G-805307', 'IMG-654be906a9fb26.35473431.jpg', 'card,cards,cartes,carte, vœux, greeting', 'W-873703', '19.99', 'Dimensions : 0,28 pouces d\'épaisseur ; 0,32 onces de poids\n\nNuméro de modèle : VariableDenomination', 'Amazon', '2024-04-09 17:12:35'),
(49, 'BRACELET LA MÈRE DES PERLES', 24, 'Bracelets', 'BA-246336', 'bracelet1.jpg', 'bracelet, perle,Bracelet, Bijoux, Accessoires,Mode, Fantaisie, Chic, Élégant, Moderne, \'Vintage\', \'Luxe\',\n    \'Perles\', Argent, Or, Cuir, Pierre, Cristal, Acier inoxydable, Charms, Cadeau, Femme,\n,Personnalisé,Artisanal,Tendance,Minimaliste,Bohème,Ethniqu', 'W-953113', '29.99', 'Bracelet perlé ressort mode à breloque papillon élastique avec peinture à l\'huile ', 'Barbie', '2024-04-09 17:12:35'),
(51, 'Black Leather Portefeuille', 1, 'Portefeuille', 'BL-860324', 'IMG-654c8b30e5a399.08493357.png', 'portefeuille, femme, leather,élégnce,card, carte, wallet, women woman, wallets, wallet,black,leather,wallets,for,men/women,unisex,best,wallet,for,women,and,men,wallets,stride', 'W-934079', '19.99', 'Portefeuille élégant en véritable cuir noir. Design épuré et minimaliste avec fermeture zippée. Compartiments pratiques pour ranger vos cartes, espèces et monnaie. Un accessoire de mode durable et fonctionnel pour tous les jours.', 'STRIDE', '2024-04-09 17:12:35'),
(52, 'Chapeau de Paille avec Décoration Noeud', 22, 'Chapeaux', 'BA-308884', 'Chapeau1.jpg', 'chapeau,chapeaux, hat,hats, fashion, accessory, style, trend, elegant, chic, vintage, modern, luxury, premium, designer, couture, straw, felt, wool, cotton, linen, leather, suede, bow, ribbon, feather, embroidery, beading, buckle, strap, brim, crown', 'W-618774', '19.99', 'Chapeau d\'été chic en paille tressée, agrémenté d\'un élégant nœud en tissu satiné. Un accessoire mode incontournable pour sublimer vos looks de saison. La décoration nouée apporte une touche féminine et raffinée.', 'Basics', '2024-04-09 17:23:39'),
(54, 'Chapeau de décoration de fleurs et de bandes', 12, 'Chapeaux', 'FI-577773', 'Chapeau2.jpg', 'chapeaux,chapeau, hat,hats,fleurs,flowers,bandes,fashion, accessory, style, trend, elegant, chic, vintage, modern, luxury, premium, designer, couture, straw, felt, wool, cotton, linen, leather, suede, bow, ribbon, feather, embroidery, beading, buckle, str', 'W-475976', '49.99', 'Chapeau d\'été élégant en paille tressée, décoré d\'un bouquet de fleurs colorées et d\'une bande de tissu satiné. Crée une touche féminine et tendance pour vos looks estivaux.', 'Soeez', '2024-04-09 19:35:56'),
(56, 'Un chapeau de mariée Happy Chantilly - Aquarelle, maman et le style de vie lent', 12, 'Chapeaux', 'FI-474044', 'Chapeau3.jpg', 'chapeau,chapeaux,hats,mariée,bride, hat, fashion,cuir, accessory, style, trend, elegant, chic, vintage, modern, luxury, premium, designer, couture, straw, felt, wool, cotton, linen, leather, suede, bow, ribbon, feather, embroidery, beading, buckle, strap,', '0', '79.99', 'Chapeau de mariée en tulle Chantilly aquarelle. Un design romantique et bohème pour une mariée éprise de douceur et d\'authenticité. Inspiré du style de vie lent et de l\'esthétique maternelle. Accessoire unique et délicat pour une allure pure et féminine.', 'Basics', '2024-04-09 20:17:10'),
(57, 'Montana West Tote Sacs à Main', 12, 'Sacs à main', 'HA-951876', 'IMG-6551418318fff5.71340346.jpg', 'Sacs,sac,bag,bags,main, Handbags, Pochette, Pouch, Velours doux, Soft Velvet, Tarot, Tarot, Autels, Altars, Runes, Runes, Cadeaux, Gifts, Cristaux, Crystals, Bijoux, Jewelry', 'W-258369', '199.99', 'Sacs fourre-tout tendance en cuir haut de gamme. Style western raffiné avec finitions artisanales. Design spacieux et polyvalent pour un look mode sophistiqué..', 'Montana West ', '2024-04-09 20:20:03'),
(58, 'Sac en Cuir, Leather Bag', 13, 'Sacs à main', 'HA-964114', 'IMG-655141e2db3048.34677781.jpg', 'Sacs,bags,main,sac,Handbag, Pochette, Pouch, Velours doux, Soft,handbag Velvet, Tarot, Tarot, Autels, Altars, Runes, Runes, Cadeaux, Gifts, Cristaux, Crystals, Bijoux, Jewelry', '0', '419.99', 'Sac en véritable cuir de haute qualité. Design multifonctionnel pouvant se porter en bandoulière, à l\'épaule ou en cabas. Élégant et spacieux, parfait pour le travail, les sorties ou les voyages. Un accessoire mode essentiel et durable.', 'Dreubea ', '2024-04-09 20:21:38'),
(59, 'Sac à Main ALARION pour Femmes', 12, 'Sacs à main', 'HA-567841', 'IMG-6551426dc13b23.38645210.jpg', 'Sacs,sac,bag,bags,main, Handbags, Pochette, Pouch, Velours doux, Soft Velvet, Tarot, Tarot, Autels, Altars, Runes, Runes, Cadeaux, Gifts, Cristaux, Crystals, Bijoux, Jewelry', '0', '159.99', 'Sac à main de style satchel avec poignée supérieure. Design sophistiqué en cuir de qualité. Se porte à l\'épaule ou en bandoulière. Parfait comme sac à main, sac de messager ou cabas de travail. Un accessoire mode polyvalent et durable.', 'ALARION ', '2024-04-09 20:23:57'),
(60, 'Masques pour le Contour des Yeux NAZANO', 25, 'Produits de beauté', 'BE-619200', 'IMG-655142e086a0b7.28444304.jpg', 'Produits,beauté, Beauty,Products, Cosmétiques, Cosmetics, Maquillage, Makeup, Soins,peau, Skincare, Parfums, Fragrances, Accessoires, Accessories, Beauté, Beauty, Hygiène, Hygiene, Bain,Corps,masque', 'W-982395', '29.99', 'Patchs pour le contour des yeux - 30 paires - Masque à l\'Or 24 Carats', 'NAZANO ', '2024-04-09 20:25:52'),
(61, 'Brillant à Lèvres Teinté NYX PROFESSIONAL MAKEUP Fat Oil Lip Drip', 24, 'Produits de beauté', 'BE-149088', 'IMG-65514329cbe6f6.34393286.jpg', 'Produits,beauté,Lèvres,Brillant,NXY, Beauty,Products, Cosmétiques,Brillant,Lèvres,Cosmetics, Maquillage, Makeup, Soins de la,peau, Skincare, Parfums, Fragrances, Accessoires, Accessories, Beauté', 'W-530779', '12.99', 'Hydratant, brillant et végan\n\nCouleur : Missed Call (Rose Nacré)', 'NYX', '2024-04-09 20:27:05'),
(62, 'Pochette en Velours Doux', 12, 'Accessoires Cadeaux', 'GI-228414', 'pochette.jpg', 'Pochette,Accessoires, Cadeaux,Pochette, Velours doux, Tarot, Autels, Runes, Cadeaux, Cristaux, Bijoux', 'W-616514', '99.99', 'Sac en velours souple pour ranger et transporter vos objets précieux, sacrés et spirituels.\nColoris : Or', 'Cosigners', '2024-04-09 20:29:45'),
(63, 'Arbre de Bonsaï en Cristaux de Pierres Précieuses', 12, 'Accessoires Cadeaux', 'GI-159974', 'IMG-6551442f9cc9b1.77534393.jpg', 'cadeau,gift, gifts, designs, painting,pierres,tree,subsh,seven,chakra,natural,healing,gemstone,crystal,bonsai,fortune,money,tree,for,good,luck,,wealth,&,prosperity,home,office,kitchen,décor,spiritual,gift,,gift,articles,subsh,cadeaux', 'W-619851', '119.99', 'Arbre de bonsaï décoratif en cristaux naturels représentant les 7 chakras. Favorise la chance, la richesse et la prospérité dans la maison, le bureau ou la cuisine. Un cadeau spirituel et zen.', 'SUBSH ', '2024-04-09 20:31:27'),
(64, 'Kit d\'Art Complet 241 Pièces', 12, 'Arts', 'AR-923777', 'IMG-6551447f8aef68.68044762.jpg', 'art,kit,arts, pencils, pencil, pen, stationary, stationaries,art,supplies,,241,pcs,drawing,art,kit,for,kids,boys,girls,,deluxe,art,and,craft,set,with,double,sided,trifold,easel,,markers,,oil,pastels,arts,art,supplies', '0', '9.99', 'Ensemble d\'art et d\'artisanat de luxe pour enfants, avec chevalet, marqueurs, pastels à l\'huile et plus. Tout le nécessaire pour développer la créativité.', 'Art Supplies', '2024-04-09 20:32:47'),
(65, 'Ensemble de Carnets à Croquis', 12, 'Arts', 'AR-132487', 'IMG-655144c27dfe83.05349840.jpg', 'carnets,carnet,croquis,arts, books, book, sketch, eraser, ,5.5\",x,8.5\",sketchbook,set,,top,spiral,bound,sketch,pad,,2,packs,100-sheets,each,(68lb/100gsm),,acid,free,art,sketch,book,artistic,drawing,painting,writing,paper,for,beginners,artists,arts,fuxi', 'W-667715', '12.99', 'Ensemble de Carnets à Croquis 5,5\" x 8,5\"\n\n    2 carnets à spirale de 100 feuilles\n    Papier sans acide pour dessin et peinture\n    Idéal pour débutants et artistes\n', 'Fuxi', '2024-04-09 20:33:54'),
(66, 'Portefeuille en Cuir Steve Madden', 25, 'Portefeuilles', 'WA-357731', 'IMG-6551453c77de88.50033211.jpg', 'portefeuilles, portefeuille,wallets,wallet', 'W-634967', '179.99', 'Un portefeuille en cuir de qualité, offrant un espace de rangement généreux pour vos cartes et espèces.\n    -Capacité supplémentaire\n    -Poche rabattante\n    - Design élégant et pratique\n    -Marque réputée Steve Madden\n', 'Steve Madden', '2024-04-09 20:35:56'),
(68, 'Bracelet Rose Lune Perlé Étoile Pour Femme', 25, 'Bracelets', 'DO-365294', 'bracelet2.jpg', 'bracelet, perle,Bracelet, Bijoux, Accessoires,Mode, Fantaisie, Chic, Élégant, Moderne, \'Vintage\', \'Luxe\',\n    \'Perles\', Argent, Or, Cuir, Pierre, Cristal, Acier inoxydable, Charms, Cadeau, Femme,\n,Personnalisé,Artisanal,Tendance,Minimaliste,Bohème', '0', '19.99', '- Design féminin et délicat\n- Perles roses et éléments argentés\n- Motifs lune et étoiles\n- Bracelet tendance pour femme', 'Barbie', '2024-11-09 21:38:50'),
(69, 'Bracelet Arbre de Vie Argenté', 12, 'Bracelets', 'DO-215795', 'bracelet3.jpg', 'bracelet, perle,Bracelet, Bijoux, Accessoires,Mode, Fantaisie, Chic, Élégant, Moderne, \'Vintage\', \'Luxe\',\n    \'Perles\', Argent, Or, Cuir, Pierre, Cristal, Acier inoxydable, Charms, Cadeau, Femme,\n,Personnalisé,Artisanal,Tendance,Minimaliste,Bohème', 'W-126504', '39.99', 'Bracelet Arbre de Vie Argenté\n-Cristaux et breloques\n-Design mode et tendance\n-Bijou fantaisie élégant\n\nUn bracelet décoratif aux motifs floraux et naturels, avec des éléments argentés. Un accessoire de mode raffiné et tendance.\n', 'Barbie', '2024-04-09 20:39:51'),
(71, 'Coffret de 40 Cartes de Vœux de Noël Hallmark', 25, 'Cartes de Vœux', 'GR-773455', 'IMG-65514718173b10.65987289.jpg', 'card,cards,cartes, Vœux, greeting,thank you, thanks, thank card, thankyou cards,hallmark,boxed,holiday,cards,greetings,snowflake,40,holiday,cards,with,envelopes,greeting,cards,hallmark', '0', '9.99', '- Motifs flocons de neige\n- Avec enveloppes assorties\n- Design festif et élégant\n- Marque Hallmark reconnue', 'Hallmark', '2024-04-09 20:43:52');

-- --------------------------------------------------------

--
-- Structure de la table `returns`
--

CREATE TABLE `returns` (
  `return_id` int(11) NOT NULL,
  `order_id` varchar(255) NOT NULL,
  `order_num` varchar(255) NOT NULL,
  `customer_id` varchar(255) NOT NULL,
  `return_item` varchar(255) NOT NULL,
  `return_item_quantity` varchar(255) NOT NULL,
  `return_details` varchar(255) NOT NULL,
  `return_status` varchar(255) NOT NULL,
  `return_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `returns`
--

INSERT INTO `returns` (`return_id`, `order_id`, `order_num`, `customer_id`, `return_item`, `return_item_quantity`, `return_details`, `return_status`, `return_date`) VALUES
(4, '39', '971952403776', '24', ' G-805307', ' 1', '', 'returned', '2024-05-12 10:28:11'),
(5, '48', 'C_15012880437151', '24', 'BA-308884', '1', 'Not good prodcut', 'returned', '2024-05-12 19:04:59');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin Id`);

--
-- Index pour la table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Cart Id`),
  ADD KEY `Customer Id` (`Customer Id`);

--
-- Index pour la table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category Id`);

--
-- Index pour la table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer Id`);

--
-- Index pour la table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`Order Id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`Product Id`);

--
-- Index pour la table `returns`
--
ALTER TABLE `returns`
  ADD PRIMARY KEY (`return_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `cart`
--
ALTER TABLE `cart`
  MODIFY `Cart Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `category`
--
ALTER TABLE `category`
  MODIFY `Category Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT pour la table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `order`
--
ALTER TABLE `order`
  MODIFY `Order Id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `Product Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT pour la table `returns`
--
ALTER TABLE `returns`
  MODIFY `return_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `Customer Id` FOREIGN KEY (`Customer Id`) REFERENCES `customer` (`Customer Id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
