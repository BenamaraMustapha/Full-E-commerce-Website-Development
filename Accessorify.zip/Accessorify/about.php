<?php include 'config.php'; ?>
<?php include 'functions.php'; ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- META TITLE AND DESCRIPTION -->
    <meta name="description" content="">
    <meta name="keywords" content="">
    <!-- META TITLE AND DESCRIPTION -->


    <!--==== HEADER STYLES START ====-->
    <?php include('includes/header-styles.php') ?>
    <!--==== HEADER STYLES END ====-->
    <title>About | <?php echo $site__name; ?></title>
</head>

<body>

    <!--==== HEADER START ====-->
    <?php include('includes/header.php') ?>
    <!--==== HEADER END ====-->


    <main>
        <section class="pb-0">
            <div class="">
                <div class="container">
                    <div class="content-card ff-secondary py-5 px-4 border w-50 m-auto text-center">
                        <h2 class="fs-24 mb-15 ff-secondary fw-300 text-capitilize text-balance text-wrap">À PROPOS DE NOUS</h2>
                        <p class="fs-15 ff-secondary fw-300">Explorez une fusion exquise de qualité et de diversité <br> Votre havre multi-catégorie tout-en-un

                        </p>
                    </div>
                </div>
            </div>
        </section>

        <section class="aboutCardSection">
            <div class="container">
                <div class="about-card mb-30 row align-items-center border px-5 py-5 bg-white">
                    <div class="col-md-6 col-12">
                        <img src="assets/images/1.jpg" alt="">
                    </div>
                    <div class="col-md-6 col-12">
                        <h4 class="fs-22 fw-300 fc-secondary mb-15">QUI SOMMES-NOUS ?

                        </h4>
                        <p class="fs-14 fw-300 ff-primary" style="line-height: 1.4;">Bienvenue chez ACCESSORIFY, où le luxe discret rencontre l'élégance intemporelle. Nous sommes fiers de nos accessoires conçus à Marseille, qui sont méticuleusement fabriqués pour illustrer un sentiment de sophistication subtile. En tant que petite entreprise ambitieuse, nous nous faisons une place dans l'industrie de la mode en promouvant l'idée que le vrai luxe ne nécessite pas de marquage excessif. Nos collections comprennent des accessoires de mode abordables et simplistes qui permettent à la qualité et au savoir-faire de parler d'eux-mêmes. Rejoignez-nous pour embrasser le charme subtil du luxe discret chez ACCESSORIFY.

                        </p>
                    </div>
                </div>
                <div class="about-card mb-30 row align-items-center border px-5 py-5 bg-white">
                    <div class="col-md-6 col-12">
                        <h4 class="fs-22 fw-300 fc-secondary mb-15">CONTRIBUER À LA COMMUNAUTÉ



                        </h4>
                        <p class="fs-14 fw-300 ff-primary" style="line-height: 1.4;">Chez ACCESSORIFY, nous croyons en la mode qui fait la différence. Avec chaque commande que vous passez, nous sommes fiers de contribuer 1,5 euros pour soutenir des organisations dédiées à aider les enfants dans les pays déchirés par la guerre. Ensemble, nous cousons l'espoir, un accessoire à la fois, et faisons une différence dans la vie des personnes qui en ont le plus besoin. Avec chaque achat, permettez-nous de diffuser non seulement du style, mais aussi de la compassion et des soins.


                        </p>
                    </div>
                    <div class="col-md-6 col-12">
                        <img src="assets/images/2.jpg" alt="">
                    </div>
                </div>
                <div class="about-card mb-30 row align-items-center border px-5 py-5 bg-white">
                    <div class="col-md-6 col-12">
                        <img src="assets/images/3.jpg" alt="">
                    </div>
                    <div class="col-md-6 col-12">
                        <h4 class="fs-22 fw-300 fc-secondary mb-15">NOTRE MISSION



                        </h4>
                        <p class="fs-14 fw-300 ff-primary" style="line-height: 1.4;">Notre mission chez ACCESSORIFY est claire : autonomiser notre clientèle avec la fusion ultime de la mode et du confort. Nous sommes en quête de réinventer votre expérience avec les accessoires, une où le style et le confort vivent ensemble. Plus de compromis - avec ACCESSORIFY, vous trouverez instantanément le juste équilibre où le confort rencontre le chic, faisant une déclaration à la fois élégante et confortable.



                        </p>
                    </div>

                </div>
            </div>
        </section>
    </main>
    <!--==== FOOTER START ====-->
    <?php include('includes/footer.php') ?>
    <!--==== FOOTER END ====-->
</body>

</html>