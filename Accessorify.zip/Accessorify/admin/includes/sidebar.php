<aside class="dashboard--sidebar">
    <ul class="sidebar-list">
        <li class="d-flex gap-10 text-center">
            <button data-show=".customer-section">Clients</button>
            <button data-show=".employee-section">Employés</button>
        </li>
        <li>
            <hr>
        </li>
        <li><button data-show=".product-section" class="active">Produits</button></li>
        <li><button data-show=".orders-section">Commandes </button></li>
        <li><button data-show=".returns-section">Retours</button></li>
        <li><button data-show=".category-section">Catégories</button></li>
        <li><button data-show=".messages-section">Messages</button></li>
    </ul>
</aside>