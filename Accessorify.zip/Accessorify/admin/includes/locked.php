<div class="lockedSection">
    <div class="lockedMain">
        <div class="icon">
            <i class="ri-git-repository-private-fill"></i>
        </div>
        <p class="py-4 fs-18">Vous n'avez pas les droits pour accéder à cette section.</p>
    </div>
</div>