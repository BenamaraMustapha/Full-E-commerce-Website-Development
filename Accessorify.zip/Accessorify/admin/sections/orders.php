<div class="position-relative orders-section">
  <div class="order-section">
    <div class="text-left">
      <h4 class="fs-30 py-4 border-bottom-hr mb-0 fc-secondary-300 fw-300">Commandes/Soldes:</h4>
    </div>
    <div class="d-flex border-bottom-hr justify-content-between py-3">
      <div class="d-flex align-items-center gap-10">
        <p class="fs-16 border-right"><span class="fc-secondary fw-500">Nombre total de commandes</span> <?php echo count(Customer::fetchAllOrders()); ?></p>
      </div>
    </div>

    <div class="ordersAreaButton">
      <div class="row py-4">
        <div class="col-lg-3 pl-2">
          <button data-show-orders=".inProcessOrders" class="btn btn-warning btn-lg active">En cours de traitement</button>
        </div>
        <div class="col-lg-3 pr-2">
          <button data-show-orders=".filledOrders" class="btn alert-primary btn-lg">Commandes envoyées</button>
        </div>
        <div class="col-lg-3 pr-2">
          <button data-show-orders=".deliveredOrders" class="btn alert-success btn-lg">Commandes livrées</button>
        </div>
        <div class="col-lg-3 pr-2">
          <button data-show-orders=".cancelOrders" class="btn btn-danger btn-lg">Commandes annulées</button>
        </div>
      </div>
    </div>

    <div class="orderArea">
      <div class="inProcessOrders">
        <?php
        $orders = Customer::fetchSpecificProducts('Order Status', 'processing');
        $orderCount = count($orders);
        ?>
        <div class="d-flex mb-10 justify-content-between">
          <p class="fs-16">Nombre total de commandes: <?php echo $orderCount; ?></p>
        </div>
        <?php if ($orderCount <= 0) { ?>
          <div class="orderHistory d-flex">
            <p class="text-center pt-5 fs-20 fw-400 fc-secondary-400">Nombre total de commandes en cours de traitement</p>
          </div>
        <?php } else { ?>

          <h4 class="text-center pb-4">Commande à préparer</h4>
          <table class="table text-left">
            <thead>
              <tr>
                <th>Commande #</th>
                <th>Effectué le</th>
                <th>Articles</th>
                <th>Total</th>
                <th>Méthode de paiement</th>
                <th>État de la commande</th>
                <th class="text-center">Informations:</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach ($orders as $order) {
                $orderId = $order["Order Id"];
                $orderNum = $order["Order Number"];
                $orderType = $order["Order Type"];
                $orderAmount = $order["Order Amount"];
                $orderDate = $order["Order Date"];
                $orderItems = explode(",", $order["Order Items"]);
                $orderStatus = $order["Order Status"];
              ?>
                <tr>
                  <td>
                    <?php echo $orderNum; ?>
                  </td>
                  <td>
                    <?php echo $orderDate; ?>
                  </td>
                  <td>
                    <?php
                    $productArray = array();
                    foreach ($orderItems as $item) {
                      $productArray[] = checkCurrentProduct($item);
                    }
                    foreach ($productArray as $product) { ?>
                      <img class="orderImg" src="../assets/images/product-images/<?php echo $product->images ?>">
                    <?php } ?>
                  </td>
                  <td>
                    <?php echo $currencySymbol; ?><?php echo $orderAmount; ?>
                  </td>
                  <td>
                    <?php echo $orderType; ?>
                  </td>
                  <td>
                    <?php echo $orderStatus; ?>
                  </td>
                  <td class="text-center">
                    <button class="addHover manageOrder" data-toggle="modal" data-target="#manageOrderModal" data-id="<?php echo $orderId ?>">Manage</button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        <?php } ?>
      </div>
      <div class="filledOrders hidden">
        <?php
        $orders = Customer::fetchSpecificProducts('Order Status', 'shipped');
        $orderCount = count($orders);
        ?>
        <div class="d-flex mb-10 justify-content-between">
          <p class="fs-16">No of Orders: <?php echo $orderCount; ?></p>
        </div>
        <?php if ($orderCount <= 0) { ?>
          <div class="orderHistory d-flex">
            <p class="text-center pt-5 fs-20 fw-400 fc-secondary-400">Pas de commandes envoyées encore.</p>
          </div>
        <?php } else { ?>

          <h4 class="text-center pb-4">Commandes envoyées</h4>
          <table class="table text-left">
            <thead>
              <tr>
                <th>Commande #</th>
                <th>Date de la commande</th>
                <th>Date de la livraison estimée:</th>
                <th>Articles</th>
                <th>Total</th>
                <th>Méthode de paiement</th>
                <th>État de la commande</th>
                <th class="text-center">Mettre à jour l'état de livraison</th>
              </tr>
            </thead>
            <tbody>
              <?php
              foreach ($orders as $order) {
                $orderId = $order["Order Id"];
                $orderNum = $order["Order Number"];
                $orderType = $order["Order Type"];
                $orderAmount = $order["Order Amount"];
                $orderDate = $order["Order Date"];
                $orderItems = explode(",", $order["Order Items"]);
                $orderStatus = $order["Order Status"];
                $orderEstiDelivery = $order["est_delivery_date"];
              ?>
                <tr>
                  <td>
                    <?php echo $orderNum; ?>
                  </td>
                  <td>
                    <?php echo $orderDate; ?>
                  </td>
                  <td>
                    <?php echo $orderEstiDelivery; ?>
                  </td>
                  <td>
                    <?php
                    $productArray = array();
                    foreach ($orderItems as $item) {
                      $productArray[] = checkCurrentProduct($item);
                    }
                    foreach ($productArray as $product) { ?>
                      <img class="orderImg" src="../assets/images/product-images/<?php echo $product->images ?>">
                    <?php } ?>
                  </td>
                  <td>
                    <?php echo $currencySymbol; ?><?php echo $orderAmount; ?>
                  </td>
                  <td>
                    <?php echo $orderType; ?>
                  </td>
                  <td class="text-primary">
                    <?php echo $orderStatus; ?>
                  </td>
                  <td class="text-center">
                    <button class="addHover btn btn-success" data-delivery-order data-id="<?php echo $orderId ?>">Marquer comme livrée</button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        <?php } ?>
      </div>
      <div class="deliveredOrders hidden">
        <?php
        $orders = Customer::fetchSpecificProducts('Order Status', 'delivered');
        $orderCount = count($orders);
        ?>
        <div class="d-flex mb-10 justify-content-between">
          <p class="fs-16">Nombre de commandes: <?php echo $orderCount; ?></p>
        </div>
        <?php if ($orderCount <= 0) { ?>
          <div class="orderHistory d-flex">
            <p class="text-center pt-5 fs-20 fw-400 fc-secondary-400">Pas de commande livrées jusqu'à présent</p>
          </div>
        <?php } else { ?>

          <h4 class="text-center pb-4">Commandes livrées:</h4>
          <table class="table text-left">
            <thead>
              <tr>
                <th>Commande #</th>
                <th>Date de Commande</th>
                <th>Date de livraison:</th>
                <th>Articles</th>
                <th>Total</th>
                <th>Méthodes de paiement</th>
                <th>État de la commande</th>

              </tr>
            </thead>
            <tbody>
              <?php
              foreach ($orders as $order) {
                $orderId = $order["Order Id"];
                $orderNum = $order["Order Number"];
                $orderType = $order["Order Type"];
                $orderAmount = $order["Order Amount"];
                $orderDate = $order["Order Date"];
                $orderItems = explode(",", $order["Order Items"]);
                $orderStatus = $order["Order Status"];
              ?>
                <tr>
                  <td>
                    <?php echo $orderNum; ?>
                  </td>
                  <td>
                    <?php echo $orderDate; ?>
                  </td>
                  <td>
                    <?php echo '24.24.24    '; ?>
                  </td>
                  <td>
                    <?php
                    $productArray = array();
                    foreach ($orderItems as $item) {
                      $productArray[] = checkCurrentProduct($item);
                    }
                    foreach ($productArray as $product) { ?>
                      <img class="orderImg" src="../assets/images/product-images/<?php echo $product->images ?>">
                    <?php } ?>
                  </td>
                  <td>
                    <?php echo $currencySymbol; ?><?php echo $orderAmount; ?>
                  </td>
                  <td>
                    <?php echo $orderType; ?>
                  </td>
                  <td class="text-success">
                    <?php echo $orderStatus; ?>
                  </td>

                </tr>
              <?php } ?>
            </tbody>
          </table>
        <?php } ?>
      </div>
      <div class="cancelOrders hidden">
        <?php
        $orders = Customer::fetchSpecificProducts('Order Status', 'cancelled');
        $orderCount = count($orders);
        ?>
        <div class="d-flex mb-10 justify-content-between">
          <p class="fs-16">No of Orders: <?php echo $orderCount; ?></p>
        </div>
        <?php if ($orderCount <= 0) { ?>
          <div class="orderHistory d-flex">
            <p class="text-center pt-5 fs-20 fw-400 fc-secondary-400">0 commandes annulées.</p>
          </div>
        <?php } else { ?>

          <h4 class="text-center pb-4">Commanes annulées:</h4>
          <table class="table text-left">
            <thead>
              <tr>
                <th>Commande #</th>
                <th>Date de la commande</th>
                <th>Articles</th>
                <th>Total</th>
                <th>Méthode de paiement</th>
                <th>État de la commande</th>
                <th>Anulée par</th>
                <!-- <th class="text-center">Info:</th> -->
              </tr>
            </thead>
            <tbody>
              <?php
              foreach ($orders as $order) {
                $orderId = $order["Order Id"];
                $orderNum = $order["Order Number"];
                $orderType = $order["Order Type"];
                $orderAmount = $order["Order Amount"];
                $orderDate = $order["Order Date"];
                $orderItems = explode(",", $order["Order Items"]);
                $orderStatus = $order["Order Status"];
                $orderReason = $order["reason"];
                $orderCancelBy = $order["cancel_by"];
              ?>
                <tr>
                  <td>
                    <?php echo $orderNum; ?>
                  </td>
                  <td>
                    <?php echo $orderDate; ?>
                  </td>
                  <td>
                    <?php
                    $productArray = array();
                    foreach ($orderItems as $item) {
                      $productArray[] = checkCurrentProduct($item);
                    }
                    foreach ($productArray as $product) { ?>
                      <img class="orderImg" src="../assets/images/product-images/<?php echo $product->images ?>">
                    <?php } ?>
                  </td>
                  <td>
                    <?php echo $currencySymbol; ?><?php echo $orderAmount; ?>
                  </td>
                  <td>
                    <?php echo $orderType; ?>
                  </td>
                  <td class="text-danger">
                    <?php echo $orderStatus; ?>
                  </td>
                  <td>
                    <?php echo $orderCancelBy; ?>
                  </td>
                </tr>
              <?php } ?>
            </tbody>
          </table>
        <?php } ?>
      </div>
    </div>



  </div>
</div>

<div class="modal fade" id="manageOrderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fs-24" id="orderModalLabel">Détails de la commande</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Order details will be dynamically populated here using JavaScript -->
        <h4 class="fs-24 border-bottom-hr pb-2 w-25 mb-10">Information du client:</h4>
        <div class="row">
          <div class="input__wrap col-md-4 col-6 py-2">
            <label for="">Nom Client</label>
            <input readonly type="text" class="border py-2 px-2  customer_name">
          </div>
          <div class="input__wrap col-md-4 col-6 py-2">
            <label for="">Adresse Client</label>
            <input readonly type="text" class="border py-2 px-2  customer_address">
          </div>
          <div class="input__wrap col-md-4 col-6 py-2">
            <label for="">Ville Client</label>
            <input readonly type="text" class="border py-2 px-2  customer_city">
          </div>
          <div class="input__wrap col-md-4 col-6 py-2">
            <label for="">Client téléphone</label>
            <input readonly type="text" class="border py-2 px-2  customer_phone">
          </div>
        </div>

        <h4 class="fs-24 border-bottom-hr pb-2 w-25 mb-10 pt-3">Informations sur la commande:</h4>
        <div class="row">

          <div class="row col-12 py-2">
            <p class="py-2 col-3"><strong>Commande # </strong><span class="manageOrderNo"></span></p>
            <p class="py-2 col-3"><strong>Date de la commande </strong><span class="manageOrderDate"></span></p>
            <p class="py-2 col-3"><strong>Type de la commande </strong><span class="manageOrderType"></span></p>
          </div>
          <div class="input__wrap col-md-4 col-6 py-2">
            <label for="">Articles de la commande</label>
            <div class="list-group manageOrderItems">

            </div>
          </div>
          <div class="input__wrap col-md-4 col-6 py-2">
            <label for="">Commande Totale</label>
            <input readonly type="text" value="" class=" py-2 px-2 order_total">
          </div>
          <div class="input__wrap col-md-4 col-6 py-2">
            <label for="">État de la commande</label>
            <select value="" class="order_status w-100 border py-2 px-2">
              <option value="processing" selected>En cours de traitement</option>
              <option value="shipped">livrée</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer d-flex justify-content-between" style="min-height: 70px">
        <button type="button" class="btn btn-danger" data-cancel-order data-id="" data-cancel-by="admin">Annuler la commande</button>
        <button type="button" class="btn btn-secondary hidden updateOrderStatusButton" data-update-order-status data-id="" data-dismiss="modal">Mettre à jour l'état de la commande</button>
      </div>
    </div>
  </div>
</div>