<section class="banner-section pt-0">
    <div class="position-relative">
        <div class="banner-section-slider_">
            <div class="item">
                <img src="assets/images/banner.jpg" alt="">
            </div>
           
        </div>
        <div class="bannerText">
            <div class="wrapper ff-secondary text-center">
                <h6 class="fs-14 mb-10 fw-300 fc-primary">OFFRES EXCLUSIVES !</h6>
                <h1  class="mb-30 ff-primary fw-300 fc-primary text-uppercase">Soldes Sur Accessorify</h1>
                <p class="fs-14 mb-30 ff-primary fw-300 fc-primary">Profitez de 20 % de réduction sur les Must-Haves</p>
                <div class="d-md-flex gap-10">
                    <a href="catalogue.php" class="btn btn-secondary">PROFITER ET ACHETER MAINTENANT</a>
                    <a href="about.php" class="btn btn-primary">EN SAVOIR PLUS</a>
                </div>
            </div>
        </div>
    </div>
</section>