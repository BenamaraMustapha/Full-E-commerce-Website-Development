<section class="brand-slider-section pt-0">
    <div class="container">
        <div class="hr__marquee brand-slider">
            <div class="hr__marqueeItem">
                <div class="brand-slider-card">
                    <h4 class="fw-700 fs-45 fc-secondary ff-secondary">Chanel</h4>
                </div>
                <div class="brand-slider-card">
                    <h4 class="fw-700 fs-45 fc-secondary ff-secondary">Vicotoria</h4>
                </div>
                <div class="brand-slider-card">
                    <h4 class="fw-700 fs-45 fc-secondary ff-secondary">Rolex</h4>
                </div>
                <div class="brand-slider-card">
                    <h4 class="fw-700 fs-45 fc-secondary ff-secondary">Picaso</h4>
                </div>
            </div>
            <div class="hr__marqueeItem" aria-hidden="true">
                <div class="brand-slider-card">
                    <h4 class="fw-700 fs-45 fc-secondary ff-secondary">Chanel</h4>
                </div>
                <div class="brand-slider-card">
                    <h4 class="fw-700 fs-45 fc-secondary ff-secondary">Vicotoria</h4>
                </div>
                <div class="brand-slider-card">
                    <h4 class="fw-700 fs-45 fc-secondary ff-secondary">Rolex</h4>
                </div>
                <div class="brand-slider-card">
                    <h4 class="fw-700 fs-45 fc-secondary ff-secondary">Picaso</h4>
                </div>
            </div>
        </div>
    </div>
</section>