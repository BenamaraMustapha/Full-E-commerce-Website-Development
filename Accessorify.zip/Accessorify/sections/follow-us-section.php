<section class="follow-us-section">
    <div class="container">
        <div class="section__text text-center">
            <h4 class="fw-300 fs-35">SUIVEZ-NOUS <a href="">@Accessorify</a></h4>
        </div>
        <div class="d-flex flex-wrap justify-content-center">
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/1.png" alt="">
                </a>
            </div>
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/2.png" alt="">
                </a>
            </div>
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/3.png" alt="">
                </a>
            </div>

            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/6.png" alt="">
                </a>
            </div>
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/1.png" alt="">
                </a>
            </div>
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/4.png" alt="">
                </a>
            </div>
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/5.png" alt="">
                </a>
            </div>
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/2.png" alt="">
                </a>
            </div>
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/5.png" alt="">
                </a>
            </div>
            <div class="gallery-cards">
                <a href="https://instagram.com" target="_blank">
                    <div class="icon__wrap">
                        <i class="ri-heart-line"></i>
                    </div>
                    <img src="assets/images/gallery/6.png" alt="">
                </a>
            </div>
        </div>
    </div>
</section>