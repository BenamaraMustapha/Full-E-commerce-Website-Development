
<section class="promotion-section pb-0 pt-0">
    <div class="py-3 bg-black">
        <div class="hr__marquee brand-slider">
            <div class="hr__marqueeItem">
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
            </div>

            <div class="hr__marqueeItem" aria-hidden="true">
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
                <div class="item">
                    <h6 class="fc-primary fs-14"><?php echo $promotionTitle; ?></h6>
                </div>
            </div>
        </div>
    </div>

    </div>
</section>